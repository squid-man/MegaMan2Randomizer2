Betterbass Sprite ripped from Mega Man Reloaded (Mega Man 1 Romhack) by Zieldak

title intro edits and sprite fixes credit to Charlieboy