CasualTom.ips is a sprite swap for use with Mega Man 2 created by Charlieboy 
AVGN sprite was altered to create this custom sprite
credit for AVGN sprite to ABOHICCUPS