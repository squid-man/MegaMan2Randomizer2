CutmanBSD.ips includes hud element swaps

CutmanBSD sprite ripped by Charlieboy
title intro edits and sprite fixes credit to Charlieboy

Credit 
Sprites ripped from Cutman's Bad Scissors Day romhack 
by JASON HAYES, EEDIOT, GENIOUS OF AMERICA, YES.